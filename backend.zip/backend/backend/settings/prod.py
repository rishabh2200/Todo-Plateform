from backend.settings.base import *

DEBUG = True

ALLOWED_HOSTS = ['*']